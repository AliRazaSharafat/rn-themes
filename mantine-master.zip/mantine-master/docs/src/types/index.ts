export type { Frontmatter } from './Frontmatter';
export type { MdxPageProps } from './MdxPageProps';
