import { createStyles } from '@mantine/styles';

export default createStyles(() => ({
  placeholder: {},
  input: {
    cursor: 'pointer',
  },
}));
