# Mantine carousel

[![npm](https://img.shields.io/npm/dm/@mantine/carousel)](https://www.npmjs.com/package/@mantine/carousel)

Embla based carousel

[View documentation](https://mantine.dev/)

## Installation

```bash
# With yarn
yarn add @mantine/core @mantine/hooks @mantine/carousel

# With npm
npm install @mantine/core @mantine/hooks @mantine/carousel
```

## License

MIT
