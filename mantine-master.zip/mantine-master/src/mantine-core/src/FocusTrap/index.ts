export { FocusTrap } from './FocusTrap';
export type { FocusTrapProps } from './FocusTrap';
