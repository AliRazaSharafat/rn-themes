export { ColorInput } from './ColorInput';
export type { ColorInputProps, ColorInputStylesNames } from './ColorInput';
