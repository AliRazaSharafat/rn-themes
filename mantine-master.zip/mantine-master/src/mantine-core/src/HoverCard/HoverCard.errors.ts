export const HOVER_CARD_ERRORS = {
  context: 'HoverCard component was not found in the tree',
  children:
    'HoverCard.Target component children should be an element or a component that accepts ref, fragments, strings, numbers and other primitive values are not supported',
};
