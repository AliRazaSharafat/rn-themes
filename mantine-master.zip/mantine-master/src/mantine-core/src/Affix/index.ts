export { Affix } from './Affix';
export type { AffixProps } from './Affix';
