export { AspectRatio } from './AspectRatio';
export type { AspectRatioProps } from './AspectRatio';
export type { AspectRatioStylesParams } from './AspectRatio.styles';
