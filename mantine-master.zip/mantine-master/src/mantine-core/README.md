# Mantine core

[![npm](https://img.shields.io/npm/dm/@mantine/core)](https://www.npmjs.com/package/@mantine/core)

Mantine core components library.

[View documentation](https://mantine.dev/)

## Installation

```bash
# With yarn
yarn add @mantine/core @mantine/hooks

# With npm
npm install @mantine/core @mantine/hooks
```

## License

MIT
