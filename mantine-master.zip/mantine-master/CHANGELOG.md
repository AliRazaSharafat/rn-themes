# Changelog

See detailed changes in [releases section](https://github.com/mantinedev/mantine/releases)
