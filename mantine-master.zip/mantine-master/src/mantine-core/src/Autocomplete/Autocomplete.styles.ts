import { createStyles } from '@mantine/styles';

export default createStyles(() => ({
  wrapper: {
    position: 'relative',
  },
}));
