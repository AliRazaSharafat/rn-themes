export { Blockquote } from './Blockquote';
export type { BlockquoteProps, BlockquoteStylesNames } from './Blockquote';
export type { BlockquoteStylesParams } from './Blockquote.styles';
