export { Highlight } from './Highlight';
export type { HighlightProps } from './Highlight';
