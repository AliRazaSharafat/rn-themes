# Greycliff CF font license

Greycliff CF font is not licensed under MIT license. Please make sure to purchase a license
if you are planning to use it in your projects.

Link to purchase – https://creativemarket.com/connary/674046-Greycliff-CF-geometric-sans-font-v2
