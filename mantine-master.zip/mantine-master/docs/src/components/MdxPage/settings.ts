export const BREAKPOINT = 1080;
export const TABLE_OF_CONTENTS_WIDTH = 260;
export const CONTENT_WIDTH = 820;
export const TAB_HEIGHT = 46;
export const TAB_HEIGHT_MOBILE = 38;
