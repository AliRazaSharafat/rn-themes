export { BackgroundImage } from './BackgroundImage';
export type { BackgroundImageProps } from './BackgroundImage';
