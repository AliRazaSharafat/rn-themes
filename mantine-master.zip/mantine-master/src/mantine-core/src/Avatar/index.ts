export { Avatar } from './Avatar';
export type { AvatarProps, AvatarStylesNames } from './Avatar';
export type { AvatarStylesParams } from './Avatar.styles';
