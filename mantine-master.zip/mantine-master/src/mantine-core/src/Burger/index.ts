export { Burger } from './Burger';
export type { BurgerProps, BurgerStylesNames } from './Burger';
export type { BurgerStylesParams } from './Burger.styles';
