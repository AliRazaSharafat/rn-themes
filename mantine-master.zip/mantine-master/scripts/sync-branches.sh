git checkout master
git pull

git checkout dev
git pull
git merge master
git push

git checkout v5
git pull
git merge dev
git push
