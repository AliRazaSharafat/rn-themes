export { Divider } from './Divider';
export type { DividerProps, DividerStylesNames } from './Divider';
export type { DividerStylesParams } from './Divider.styles';
