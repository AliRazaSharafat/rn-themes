export { Badge } from './Badge';
export type { BadgeProps, BadgeStylesNames } from './Badge';
export type { BadgeVariant, BadgeStylesParams } from './Badge.styles';
