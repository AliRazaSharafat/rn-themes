import React from 'react';
import { TipTapDemos } from '@mantine/demos';

export function RichText() {
  const Component = TipTapDemos.usage.component as any;
  return <Component />;
}
