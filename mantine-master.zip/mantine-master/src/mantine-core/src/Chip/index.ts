export { Chip } from './Chip';

export type { ChipProps, ChipStylesNames } from './Chip';
export type { ChipStylesParams } from './Chip.styles';
export type { ChipGroupProps } from './ChipGroup/ChipGroup';
