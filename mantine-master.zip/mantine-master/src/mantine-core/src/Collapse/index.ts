export { Collapse } from './Collapse';
export type { CollapseProps } from './Collapse';
