export function getDefaultValue<T>(value: T) {
  return value;
}
