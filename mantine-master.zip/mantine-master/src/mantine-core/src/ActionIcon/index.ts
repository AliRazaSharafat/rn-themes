export { ActionIcon } from './ActionIcon';

export type { ActionIconProps, ActionIconStylesNames } from './ActionIcon';
export type { ActionIconVariant, ActionIconStylesParams } from './ActionIcon.styles';
