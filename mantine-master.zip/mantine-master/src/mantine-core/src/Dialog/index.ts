export { Dialog } from './Dialog';
export type { DialogProps, DialogStylesNames } from './Dialog';
export type { DialogStylesParams } from './Dialog.styles';
