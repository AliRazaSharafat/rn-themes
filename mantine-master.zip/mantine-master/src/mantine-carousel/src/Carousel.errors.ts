export const CAROUSEL_ERRORS = {
  context: '[@mantine/carousel] Carousel.Slide was rendered outside of Carousel context',
};
